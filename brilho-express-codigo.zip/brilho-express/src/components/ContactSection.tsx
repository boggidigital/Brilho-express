import { useState, type FormEvent } from 'react';
import {
  AlertCircle,
  ArrowUpRight,
  CheckCircle2,
  MapPin,
  MessageCircle,
  Phone,
} from 'lucide-react';
import { motion } from 'motion/react';
import {
  buildWhatsAppUrl,
  BUSINESS_INFO,
  WASH_SERVICES,
} from '../data/washData';

interface FormState {
  name: string;
  phone: string;
  loadDescription: string;
  service: string;
  notes: string;
}

interface FormErrors {
  name?: string;
  phone?: string;
}

export function ContactSection() {
  const [form, setForm] = useState<FormState>({
    name: '',
    phone: '',
    loadDescription: '',
    service: WASH_SERVICES[0].title,
    notes: '',
  });
  const [errors, setErrors] = useState<FormErrors>({});
  const [submittedUrl, setSubmittedUrl] = useState<string | null>(null);

  const directWhatsappUrl = buildWhatsAppUrl(
    'Olá, equipe Brilho Express! Gostaria de tirar uma dúvida sobre os ciclos da lavanderia.'
  );

  function validate(): FormErrors {
    const nextErrors: FormErrors = {};
    if (form.name.trim().length < 2) {
      nextErrors.name = 'Informe seu nome para o atendimento.';
    }
    const digits = form.phone.replace(/\D/g, '');
    if (digits.length < 10 || digits.length > 11) {
      nextErrors.phone = 'Informe um telefone com DDD (ex: 67 99982-5833).';
    }
    return nextErrors;
  }

  function handleSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const validationErrors = validate();
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      return;
    }

    setErrors({});
    const lines = [
      `Olá, equipe Brilho Express! Me chamo ${form.name.trim()}.`,
      `Telefone: ${form.phone.trim()}`,
      form.loadDescription.trim()
        ? `Peças / volume: ${form.loadDescription.trim()}`
        : null,
      `Serviço de interesse: ${form.service}`,
      form.notes.trim() ? `Observações: ${form.notes.trim()}` : null,
    ].filter(Boolean);

    const url = buildWhatsAppUrl(lines.join('\n'));
    setSubmittedUrl(url);

    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.target = '_blank';
    anchor.rel = 'noopener noreferrer';
    anchor.click();
  }

  return (
    <section
      id="contato"
      className="border-t border-hairline bg-canvas py-24 md:py-32"
    >
      <div className="mx-auto max-w-6xl px-6 md:px-10">
        <div className="grid grid-cols-1 items-stretch gap-12 lg:grid-cols-12 lg:gap-16">
          {/* Left Column: Direct Contact Details */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.2 }}
            transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
            className="flex flex-col justify-between lg:col-span-5"
          >
            <div>
              <p className="text-sm font-medium text-ocean">Contato</p>
              <h2 className="mt-3 font-display text-[clamp(2rem,4vw,3.125rem)] font-bold leading-[1.08] text-ink">
                Fale direto com a equipe.
              </h2>
              <p className="mt-5 text-sm leading-relaxed text-ink-secondary md:text-base">
                Tire dúvidas sobre capacidade das máquinas, edredons ou planos
                mensais direto pelo nosso WhatsApp.
              </p>

              <div className="mt-10 space-y-6 border-t border-hairline pt-8">
                <div className="flex items-start gap-4">
                  <MapPin
                    className="mt-0.5 h-5 w-5 shrink-0 text-ocean"
                    strokeWidth={1.75}
                    aria-hidden="true"
                  />
                  <div>
                    <p className="text-xs font-medium text-ink-muted">
                      Endereço
                    </p>
                    <p className="mt-1 text-sm leading-relaxed text-ink">
                      {BUSINESS_INFO.address}
                    </p>
                    <a
                      href={BUSINESS_INFO.mapsUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="mt-2 inline-flex items-center gap-1 text-xs font-medium text-ocean transition-colors hover:text-ocean-hover"
                    >
                      <span>Ver localização no mapa</span>
                      <ArrowUpRight className="h-3.5 w-3.5" aria-hidden="true" />
                    </a>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <Phone
                    className="mt-0.5 h-5 w-5 shrink-0 text-ocean"
                    strokeWidth={1.75}
                    aria-hidden="true"
                  />
                  <div>
                    <p className="text-xs font-medium text-ink-muted">
                      Telefone e WhatsApp
                    </p>
                    <a
                      href={`tel:+${BUSINESS_INFO.phoneSanitized}`}
                      className="mt-1 inline-block text-sm font-medium tabular-nums text-ink transition-colors hover:text-ocean"
                    >
                      {BUSINESS_INFO.phoneDisplay}
                    </a>
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-10">
              <a
                href={directWhatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex min-h-12 items-center gap-2.5 rounded-lg bg-ocean px-6 py-3.5 text-sm font-semibold text-ocean-ink transition-colors duration-150 hover:bg-ocean-hover whitespace-nowrap"
              >
                <MessageCircle className="h-4 w-4" strokeWidth={2} aria-hidden="true" />
                <span>Conversar no WhatsApp</span>
              </a>
            </div>
          </motion.div>

          {/* Right Column: Lead Form */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.2 }}
            transition={{ duration: 0.6, delay: 0.08, ease: [0.16, 1, 0.3, 1] }}
            className="rounded-2xl border border-hairline bg-surface p-7 md:p-10 lg:col-span-7"
          >
            {submittedUrl ? (
              <div className="flex h-full flex-col justify-center py-8">
                <div className="inline-flex h-12 w-12 items-center justify-center rounded-full bg-ocean/15 text-ocean">
                  <CheckCircle2 className="h-6 w-6" aria-hidden="true" />
                </div>
                <h3 className="mt-5 font-display text-2xl font-semibold text-ink">
                  Mensagem pronta para envio
                </h3>
                <p className="mt-2 max-w-md text-sm leading-relaxed text-ink-secondary">
                  Preparamos seu atendimento com as informações informadas. Caso
                  o WhatsApp não tenha aberto automaticamente, clique abaixo.
                </p>

                <div className="mt-8 flex flex-wrap items-center gap-4">
                  <a
                    href={submittedUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex min-h-11 items-center gap-2 rounded-lg bg-ocean px-5 py-3 text-sm font-semibold text-ocean-ink transition-colors hover:bg-ocean-hover"
                  >
                    <span>Conversar no WhatsApp</span>
                    <ArrowUpRight className="h-4 w-4" aria-hidden="true" />
                  </a>
                  <button
                    type="button"
                    onClick={() => setSubmittedUrl(null)}
                    className="inline-flex min-h-11 items-center rounded-lg border border-hairline-strong px-5 py-3 text-sm font-medium text-ink-secondary transition-colors hover:text-ink"
                  >
                    Enviar outra mensagem
                  </button>
                </div>
              </div>
            ) : (
              <form onSubmit={handleSubmit} noValidate className="space-y-6">
                <div>
                  <h3 className="font-display text-2xl font-semibold text-ink">
                    Atendimento rápido
                  </h3>
                  <p className="mt-1.5 text-sm text-ink-secondary">
                    Preencha os campos e continue direto no nosso WhatsApp.
                  </p>
                </div>

                <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
                  <div>
                    <label
                      htmlFor="contact-name"
                      className="block text-xs font-medium text-ink-secondary"
                    >
                      Seu nome *
                    </label>
                    <input
                      id="contact-name"
                      name="name"
                      type="text"
                      required
                      value={form.name}
                      onChange={(e) =>
                        setForm((prev) => ({ ...prev, name: e.target.value }))
                      }
                      placeholder="Ex: Camila Souza"
                      aria-invalid={Boolean(errors.name)}
                      className="mt-2 h-11 w-full rounded-lg border border-hairline bg-canvas px-4 text-sm text-ink placeholder:text-ink-muted focus:border-ocean focus:outline-none"
                    />
                    {errors.name && (
                      <p className="mt-2 flex items-center gap-1.5 text-xs text-danger">
                        <AlertCircle className="h-3.5 w-3.5 shrink-0" aria-hidden="true" />
                        <span>{errors.name}</span>
                      </p>
                    )}
                  </div>

                  <div>
                    <label
                      htmlFor="contact-phone"
                      className="block text-xs font-medium text-ink-secondary"
                    >
                      WhatsApp / Telefone *
                    </label>
                    <input
                      id="contact-phone"
                      name="phone"
                      type="tel"
                      required
                      value={form.phone}
                      onChange={(e) =>
                        setForm((prev) => ({ ...prev, phone: e.target.value }))
                      }
                      placeholder="(67) 99999-0000"
                      aria-invalid={Boolean(errors.phone)}
                      className="mt-2 h-11 w-full rounded-lg border border-hairline bg-canvas px-4 text-sm tabular-nums text-ink placeholder:text-ink-muted focus:border-ocean focus:outline-none"
                    />
                    {errors.phone && (
                      <p className="mt-2 flex items-center gap-1.5 text-xs text-danger">
                        <AlertCircle className="h-3.5 w-3.5 shrink-0" aria-hidden="true" />
                        <span>{errors.phone}</span>
                      </p>
                    )}
                  </div>
                </div>

                <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
                  <div>
                    <label
                      htmlFor="contact-load"
                      className="block text-xs font-medium text-ink-secondary"
                    >
                      O que deseja lavar
                    </label>
                    <input
                      id="contact-load"
                      name="loadDescription"
                      type="text"
                      value={form.loadDescription}
                      onChange={(e) =>
                        setForm((prev) => ({
                          ...prev,
                          loadDescription: e.target.value,
                        }))
                      }
                      placeholder="Ex: 1 cesto de roupas, 2 edredons"
                      className="mt-2 h-11 w-full rounded-lg border border-hairline bg-canvas px-4 text-sm text-ink placeholder:text-ink-muted focus:border-ocean focus:outline-none"
                    />
                  </div>

                  <div>
                    <label
                      htmlFor="contact-service"
                      className="block text-xs font-medium text-ink-secondary"
                    >
                      Ciclo ou plano
                    </label>
                    <select
                      id="contact-service"
                      name="service"
                      value={form.service}
                      onChange={(e) =>
                        setForm((prev) => ({ ...prev, service: e.target.value }))
                      }
                      className="mt-2 h-11 w-full rounded-lg border border-hairline bg-canvas px-4 text-sm text-ink focus:border-ocean focus:outline-none"
                    >
                      {WASH_SERVICES.map((svc) => (
                        <option key={svc.id} value={svc.title}>
                          {svc.title}
                        </option>
                      ))}
                      <option value="Lavagem Simples (R$ 17,90)">
                        Lavagem Simples — R$ 17,90
                      </option>
                      <option value="Lavagem Pesada (R$ 33,90)">
                        Lavagem Pesada — R$ 33,90
                      </option>
                    </select>
                  </div>
                </div>

                <div>
                  <label
                    htmlFor="contact-notes"
                    className="block text-xs font-medium text-ink-secondary"
                  >
                    Observações (opcional)
                  </label>
                  <textarea
                    id="contact-notes"
                    name="notes"
                    rows={3}
                    value={form.notes}
                    onChange={(e) =>
                      setForm((prev) => ({ ...prev, notes: e.target.value }))
                    }
                    placeholder="Dúvida sobre tecidos, edredons ou lavagem simples e pesada"
                    className="mt-2 w-full rounded-lg border border-hairline bg-canvas p-4 text-sm text-ink placeholder:text-ink-muted focus:border-ocean focus:outline-none"
                  />
                </div>

                <button
                  type="submit"
                  className="inline-flex min-h-12 w-full items-center justify-center gap-2 rounded-lg bg-ocean px-6 py-3.5 text-sm font-semibold text-ocean-ink transition-colors duration-150 hover:bg-ocean-hover sm:w-auto"
                >
                  <span>Conversar no WhatsApp</span>
                  <ArrowUpRight className="h-4 w-4" strokeWidth={2} aria-hidden="true" />
                </button>
              </form>
            )}
          </motion.div>
        </div>
      </div>
    </section>
  );
}
