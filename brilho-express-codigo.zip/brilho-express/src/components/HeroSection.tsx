import { ArrowUpRight } from 'lucide-react';
import { motion } from 'motion/react';
import { buildWhatsAppUrl, HERO_IMAGE } from '../data/washData';
import { ResilientImage } from './ResilientImage';

export function HeroSection() {
  const whatsappHref = buildWhatsAppUrl(
    'Olá, equipe Brilho Express! Gostaria de saber mais sobre a lavanderia automática.'
  );

  return (
    <section
      id="inicio"
      className="relative flex min-h-[92svh] items-end overflow-hidden bg-canvas pb-16 pt-28 md:pb-24 md:pt-36"
    >
      <div className="absolute inset-0">
        <ResilientImage
          src={HERO_IMAGE.src}
          alt={HERO_IMAGE.alt}
          loading="eager"
          fetchPriority="high"
          className="h-full w-full object-cover object-center"
        />
        <div
          aria-hidden="true"
          className="absolute inset-0 bg-gradient-to-t from-canvas via-canvas/75 to-canvas/30"
        />
        <div
          aria-hidden="true"
          className="absolute inset-0 bg-gradient-to-r from-canvas/85 via-canvas/40 to-transparent"
        />
      </div>

      <div className="relative z-10 mx-auto w-full max-w-6xl px-6 md:px-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
          className="max-w-3xl"
        >
          <p className="mb-4 text-sm font-medium text-ocean">
            São Gabriel do Oeste · Lavanderia Automática
          </p>

          <h1 className="font-display text-[clamp(2.5rem,5.5vw,4.75rem)] font-bold leading-[1.03] tracking-tight text-ink">
            Roupas limpas e secas sem esforço.
          </h1>

          <p className="mt-5 max-w-xl text-base leading-relaxed text-ink-secondary md:text-lg">
            Máquinas automáticas de alta performance com sabão e amaciante
            inclusos, no centro de São Gabriel do Oeste.
          </p>

          <div className="mt-9">
            <a
              href={whatsappHref}
              target="_blank"
              rel="noopener noreferrer"
              className="group inline-flex min-h-12 items-center gap-3 rounded-lg bg-ocean px-6 py-3.5 text-sm font-semibold text-ocean-ink transition-colors duration-150 hover:bg-ocean-hover whitespace-nowrap"
            >
              <span>Conversar no WhatsApp</span>
              <ArrowUpRight
                className="h-4 w-4 transition-transform duration-150 group-hover:translate-x-0.5 group-hover:-translate-y-0.5"
                strokeWidth={2}
                aria-hidden="true"
              />
            </a>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
