import { BUSINESS_INFO } from '../data/washData';

export function Footer() {
  return (
    <footer className="border-t border-hairline bg-surface py-12">
      <div className="mx-auto flex max-w-6xl flex-col justify-between gap-8 px-6 md:flex-row md:items-center md:px-10">
        <div>
          <a
            href="#inicio"
            className="font-display text-lg font-bold tracking-tight text-ink"
          >
            {BUSINESS_INFO.name}
          </a>
          <p className="mt-2 text-xs text-ink-muted">
            {BUSINESS_INFO.shortAddress} · {BUSINESS_INFO.phoneDisplay}
          </p>
        </div>

        <nav
          aria-label="Links do rodapé"
          className="flex flex-wrap items-center gap-6 text-xs font-medium text-ink-secondary"
        >
          <a href="#inicio" className="transition-colors hover:text-ink">
            Início
          </a>
          <a href="#servicos" className="transition-colors hover:text-ink">
            Serviços
          </a>
          <a href="#planos" className="transition-colors hover:text-ink">
            Planos
          </a>
          <a href="#avaliacoes" className="transition-colors hover:text-ink">
            Avaliações
          </a>
          <a href="#contato" className="transition-colors hover:text-ink">
            Contato
          </a>
        </nav>

        <p className="text-xs text-ink-muted">
          © {new Date().getFullYear()} {BUSINESS_INFO.name}
        </p>
      </div>
    </footer>
  );
}
