import { ArrowUpRight } from 'lucide-react';
import { motion } from 'motion/react';
import { buildWhatsAppUrl, WASH_SERVICES, type WashService } from '../data/washData';
import { ResilientImage } from './ResilientImage';

function FeaturedServiceCard({
  service,
  className = '',
  delay = 0,
}: {
  service: WashService;
  className?: string;
  delay?: number;
}) {
  return (
    <motion.a
      href={buildWhatsAppUrl(service.whatsappMessage)}
      target="_blank"
      rel="noopener noreferrer"
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, amount: 0.2 }}
      transition={{ duration: 0.6, delay, ease: [0.16, 1, 0.3, 1] }}
      className={`group relative flex min-h-[22rem] flex-col justify-end overflow-hidden rounded-2xl border border-hairline bg-surface p-7 transition-colors duration-200 hover:border-ocean/50 md:min-h-[26rem] md:p-9 ${className}`}
    >
      {service.image && (
        <>
          <ResilientImage
            src={service.image}
            alt={service.imageAlt || service.title}
            className="absolute inset-0 h-full w-full object-cover transition-transform duration-500 ease-out group-hover:scale-[1.03]"
          />
          <div
            aria-hidden="true"
            className="absolute inset-0 bg-gradient-to-t from-canvas via-canvas/75 to-canvas/20"
          />
        </>
      )}

      <div className="relative z-10 flex items-end justify-between gap-6">
        <div className="max-w-md">
          <p className="text-xs font-medium text-ink-secondary">
            {service.index} {service.category}
          </p>
          <h3 className="mt-2 font-display text-2xl font-semibold text-ink md:text-[1.75rem]">
            {service.title}
          </h3>
          <p className="mt-2.5 text-sm leading-relaxed text-ink-secondary">
            {service.description}
          </p>
        </div>

        <span
          aria-hidden="true"
          className="inline-flex h-11 w-11 shrink-0 items-center justify-center rounded-full border border-hairline-strong bg-surface/80 text-ink transition-colors duration-150 group-hover:border-ocean group-hover:bg-ocean group-hover:text-ocean-ink"
        >
          <ArrowUpRight className="h-4 w-4" strokeWidth={2} />
        </span>
      </div>
    </motion.a>
  );
}

export function ServicesSection() {
  const photoServices = WASH_SERVICES.slice(0, 3);
  const precisionServices = WASH_SERVICES.slice(3, 6);

  return (
    <section
      id="servicos"
      className="border-t border-hairline bg-canvas py-24 md:py-32"
    >
      <div className="mx-auto max-w-6xl px-6 md:px-10">
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.2 }}
          transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
          className="flex flex-col justify-between gap-6 md:flex-row md:items-end"
        >
          <div className="max-w-xl">
            <p className="text-sm font-medium text-ocean">Serviços</p>
            <h2 className="mt-3 font-display text-[clamp(2rem,4vw,3.125rem)] font-bold leading-[1.08] text-ink">
              Tecnologia que cuida de cada tecido.
            </h2>
          </div>

          <p className="max-w-sm text-sm leading-relaxed text-ink-secondary md:text-base">
            Toque em qualquer ciclo para tirar dúvidas direto com a equipe no
            WhatsApp.
          </p>
        </motion.div>

        <div className="mt-14 grid grid-cols-1 gap-6 lg:grid-cols-12">
          <FeaturedServiceCard
            service={photoServices[0]}
            className="lg:col-span-7"
          />

          <FeaturedServiceCard
            service={photoServices[1]}
            className="lg:col-span-5"
            delay={0.08}
          />

          <FeaturedServiceCard
            service={photoServices[2]}
            className="lg:col-span-5"
            delay={0.08}
          />

          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:col-span-7">
            {precisionServices.map((service, idx) => (
              <motion.a
                key={service.id}
                href={buildWhatsAppUrl(service.whatsappMessage)}
                target="_blank"
                rel="noopener noreferrer"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.2 }}
                transition={{
                  duration: 0.6,
                  delay: 0.1 + idx * 0.06,
                  ease: [0.16, 1, 0.3, 1],
                }}
                className={`group flex flex-col justify-between rounded-2xl border border-hairline bg-surface p-7 transition-colors duration-200 hover:border-ocean/50 hover:bg-surface-elevated md:p-8 ${
                  idx === 0 ? 'sm:col-span-2' : ''
                }`}
              >
                <div className="flex items-start justify-between gap-4">
                  <div className="flex items-center gap-2 text-xs text-ink-muted">
                    <span className="font-medium text-ocean">
                      {service.index}
                    </span>
                    <span aria-hidden="true">·</span>
                    <span>{service.category}</span>
                  </div>

                  <span
                    aria-hidden="true"
                    className="inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-full border border-hairline text-ink-secondary transition-colors duration-150 group-hover:border-ocean group-hover:bg-ocean group-hover:text-ocean-ink"
                  >
                    <ArrowUpRight className="h-4 w-4" strokeWidth={2} />
                  </span>
                </div>

                <div className="mt-8">
                  <h3 className="font-display text-xl font-semibold text-ink transition-colors duration-150 group-hover:text-ocean md:text-2xl">
                    {service.title}
                  </h3>
                  <p className="mt-2.5 max-w-lg text-sm leading-relaxed text-ink-secondary">
                    {service.description}
                  </p>
                </div>
              </motion.a>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
