import { Star } from 'lucide-react';
import { motion } from 'motion/react';
import { CUSTOMER_REVIEWS } from '../data/washData';

export function ReviewsSection() {
  return (
    <section
      id="avaliacoes"
      className="border-t border-hairline bg-canvas py-24 md:py-32"
    >
      <div className="mx-auto max-w-6xl px-6 md:px-10">
        <div className="grid grid-cols-1 gap-12 lg:grid-cols-12 lg:gap-16">
          {/* Left Editorial Column */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.2 }}
            transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-4"
          >
            <p className="text-sm font-medium text-ocean">Avaliações</p>
            <h2 className="mt-3 font-display text-[clamp(2rem,3.8vw,2.85rem)] font-bold leading-[1.08] text-ink">
              Quem lava na Brilho Express recomenda.
            </h2>
            <p className="mt-5 text-sm leading-relaxed text-ink-secondary md:text-base">
              Relatos reais de quem trocou a demora de casa pela praticidade das
              máquinas automáticas no centro.
            </p>
          </motion.div>

          {/* Right Editorial Reviews List */}
          <div className="divide-y divide-hairline lg:col-span-8">
            {CUSTOMER_REVIEWS.map((review, idx) => (
              <motion.article
                key={review.id}
                initial={{ opacity: 0, y: 18 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.2 }}
                transition={{
                  duration: 0.6,
                  delay: idx * 0.08,
                  ease: [0.16, 1, 0.3, 1],
                }}
                className="py-8 first:pt-0 last:pb-0"
              >
                <div
                  className="flex items-center gap-1"
                  aria-label={`Avaliação ${review.rating} de 5 estrelas`}
                >
                  {Array.from({ length: review.rating }).map((_, starIdx) => (
                    <Star
                      key={starIdx}
                      className="h-4 w-4 fill-ocean text-ocean"
                      aria-hidden="true"
                    />
                  ))}
                </div>

                <blockquote className="mt-4 font-display text-lg font-medium leading-relaxed text-ink md:text-xl">
                  “{review.quote}”
                </blockquote>

                <div className="mt-4 flex flex-wrap items-center gap-2 text-xs text-ink-muted">
                  <span className="font-semibold text-ink-secondary">
                    {review.author}
                  </span>
                  <span aria-hidden="true">·</span>
                  <span>{review.context}</span>
                </div>
              </motion.article>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
