import { ArrowUpRight, Check } from 'lucide-react';
import { motion } from 'motion/react';
import { buildWhatsAppUrl, STUDIO_IMAGE, WASH_PLANS } from '../data/washData';
import { ResilientImage } from './ResilientImage';

export function PlansSection() {
  return (
    <section
      id="planos"
      className="border-t border-hairline bg-surface py-24 md:py-32"
    >
      <div className="mx-auto max-w-6xl px-6 md:px-10">
        {/* Asymmetric Studio Split */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.2 }}
          transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
          className="grid grid-cols-1 items-stretch gap-8 pb-24 lg:grid-cols-12 lg:gap-12"
        >
          <div className="overflow-hidden rounded-2xl border border-hairline bg-canvas lg:col-span-7">
            <ResilientImage
              src={STUDIO_IMAGE.src}
              alt={STUDIO_IMAGE.alt}
              className="aspect-[16/10] h-full w-full object-cover lg:aspect-auto"
            />
          </div>

          <div className="flex flex-col justify-center lg:col-span-5">
            <p className="text-sm font-medium text-ocean">Padrão Brilho Express</p>
            <h2 className="mt-3 font-display text-[clamp(1.85rem,3.4vw,2.75rem)] font-bold leading-[1.1] text-ink">
              Chegue com o cesto, saia com tudo limpo.
            </h2>
            <p className="mt-5 text-sm leading-relaxed text-ink-secondary md:text-base">
              Ambiente climatizado, dosagem automática de sabão e amaciante e
              bancada ampla para organizar suas roupas com tranquilidade.
            </p>
          </div>
        </motion.div>

        {/* Centered Plans Header */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.2 }}
          transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
          className="mx-auto max-w-2xl border-t border-hairline pt-20 text-center"
        >
          <p className="text-sm font-medium text-ocean">Planos & Preços</p>
          <h2 className="mt-3 font-display text-[clamp(2rem,4vw,3.125rem)] font-bold leading-[1.08] text-ink">
            Dois planos diretos, sem surpresa.
          </h2>
          <p className="mt-4 text-sm text-ink-secondary md:text-base">
            Escolha entre a lavagem do dia a dia ou a lavagem pesada com
            insumos já inclusos.
          </p>
        </motion.div>

        {/* 2 Plans Grid */}
        <div className="mx-auto mt-12 grid max-w-4xl grid-cols-1 gap-6 md:grid-cols-2 md:items-stretch">
          {WASH_PLANS.map((plan, idx) => {
            const href = buildWhatsAppUrl(plan.whatsappMessage);

            return (
              <motion.div
                key={plan.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.15 }}
                transition={{
                  duration: 0.6,
                  delay: idx * 0.08,
                  ease: [0.16, 1, 0.3, 1],
                }}
                className={`flex flex-col justify-between rounded-2xl border p-8 transition-colors duration-200 md:p-10 ${
                  plan.featured
                    ? 'border-ocean/60 bg-surface-elevated'
                    : 'border-hairline bg-canvas hover:border-hairline-strong'
                }`}
              >
                <div>
                  <div className="flex items-baseline justify-between gap-4">
                    <h3 className="font-display text-2xl font-semibold text-ink">
                      {plan.name}
                    </h3>
                    {plan.featured && (
                      <span className="text-xs font-medium text-ocean">
                        Peças volumosas
                      </span>
                    )}
                  </div>

                  <p className="mt-2 text-sm text-ink-secondary">
                    {plan.subtitle}
                  </p>

                  <div className="mt-8 border-y border-hairline py-6">
                    <div className="flex items-baseline gap-2">
                      <span className="font-display text-4xl font-bold tabular-nums tracking-tight text-ink md:text-5xl">
                        R$ {plan.priceFormatted}
                      </span>
                      <span className="text-xs text-ink-muted">
                        · {plan.unitLabel}
                      </span>
                    </div>
                  </div>

                  <ul className="mt-7 space-y-3.5">
                    {plan.features.map((feat) => (
                      <li
                        key={feat}
                        className="flex items-start gap-3 text-sm text-ink-secondary"
                      >
                        <Check
                          className="mt-0.5 h-4 w-4 shrink-0 text-ocean"
                          strokeWidth={2.2}
                          aria-hidden="true"
                        />
                        <span>{feat}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <a
                  href={href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className={`mt-9 inline-flex min-h-12 w-full items-center justify-center gap-2 rounded-lg px-5 py-3 text-sm font-semibold transition-colors duration-150 whitespace-nowrap ${
                    plan.featured
                      ? 'bg-ocean text-ocean-ink hover:bg-ocean-hover'
                      : 'border border-hairline-strong bg-surface text-ink hover:border-ocean hover:text-ocean'
                  }`}
                >
                  <span>Escolher {plan.name}</span>
                  <ArrowUpRight className="h-4 w-4" strokeWidth={2} aria-hidden="true" />
                </a>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
