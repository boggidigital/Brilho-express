import { useEffect, useState } from 'react';
import { Menu, MessageCircle, X } from 'lucide-react';
import { buildWhatsAppUrl } from '../data/washData';

const NAV_LINKS = [
  { href: '#inicio', label: 'Início' },
  { href: '#servicos', label: 'Serviços' },
  { href: '#planos', label: 'Planos' },
  { href: '#avaliacoes', label: 'Avaliações' },
  { href: '#contato', label: 'Contato' },
] as const;

export function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => {
      setScrolled(window.scrollY > 24);
    };
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const whatsappHref = buildWhatsAppUrl(
    'Olá, equipe Brilho Express! Gostaria de tirar uma dúvida sobre a lavanderia.'
  );

  return (
    <header
      className={`fixed inset-x-0 top-0 z-50 transition-colors duration-200 ${
        scrolled || mobileOpen
          ? 'border-b border-hairline bg-canvas/90 backdrop-blur-md'
          : 'bg-gradient-to-b from-canvas/80 to-transparent'
      }`}
    >
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between gap-8 px-6 md:h-20 md:px-10">
        <a
          href="#inicio"
          className="font-display text-lg font-bold tracking-tight text-ink whitespace-nowrap shrink-0 md:text-xl"
        >
          Brilho Express
        </a>

        <nav
          aria-label="Navegação principal"
          className="hidden items-center gap-8 md:flex"
        >
          {NAV_LINKS.map((item) => (
            <a
              key={item.href}
              href={item.href}
              className="relative text-sm font-medium text-ink-secondary transition-colors duration-150 hover:text-ink whitespace-nowrap shrink-0 after:absolute after:-bottom-1 after:left-0 after:h-px after:w-0 after:bg-ocean after:transition-all after:duration-200 hover:after:w-full"
            >
              {item.label}
            </a>
          ))}
        </nav>

        <div className="flex items-center gap-3 shrink-0">
          <a
            href={whatsappHref}
            target="_blank"
            rel="noopener noreferrer"
            className="hidden items-center gap-2 rounded-lg bg-ocean px-4 py-2.5 text-sm font-semibold text-ocean-ink transition-colors duration-150 hover:bg-ocean-hover whitespace-nowrap shrink-0 md:inline-flex"
          >
            <MessageCircle className="h-4 w-4" strokeWidth={2} aria-hidden="true" />
            <span>Conversar no WhatsApp</span>
          </a>

          <button
            type="button"
            onClick={() => setMobileOpen((prev) => !prev)}
            aria-expanded={mobileOpen}
            aria-label={mobileOpen ? 'Fechar menu' : 'Abrir menu'}
            className="inline-flex h-11 w-11 items-center justify-center rounded-lg border border-hairline bg-surface text-ink transition-colors hover:bg-surface-elevated md:hidden"
          >
            {mobileOpen ? (
              <X className="h-5 w-5" aria-hidden="true" />
            ) : (
              <Menu className="h-5 w-5" aria-hidden="true" />
            )}
          </button>
        </div>
      </div>

      {mobileOpen && (
        <div className="border-t border-hairline bg-canvas px-6 py-6 md:hidden">
          <nav aria-label="Menu móvel" className="flex flex-col gap-2">
            {NAV_LINKS.map((item) => (
              <a
                key={item.href}
                href={item.href}
                onClick={() => setMobileOpen(false)}
                className="flex min-h-11 items-center text-base font-medium text-ink-secondary transition-colors hover:text-ink"
              >
                {item.label}
              </a>
            ))}
            <a
              href={whatsappHref}
              target="_blank"
              rel="noopener noreferrer"
              onClick={() => setMobileOpen(false)}
              className="mt-3 inline-flex min-h-11 items-center justify-center gap-2 rounded-lg bg-ocean px-5 py-3 text-sm font-semibold text-ocean-ink transition-colors hover:bg-ocean-hover"
            >
              <MessageCircle className="h-4 w-4" strokeWidth={2} aria-hidden="true" />
              <span>Conversar no WhatsApp</span>
            </a>
          </nav>
        </div>
      )}
    </header>
  );
}
