export const BUSINESS_INFO = {
  name: 'Brilho Express',
  address: 'R. Paraná, 1958 - Centro, São Gabriel do Oeste - MS, 79490-007',
  shortAddress: 'R. Paraná, 1958 · Centro, São Gabriel do Oeste - MS',
  phoneDisplay: '(67) 99982-5833',
  phoneSanitized: '5567999825833',
  mapsUrl:
    'https://www.google.com/maps/search/?api=1&query=R.+Paran%C3%A1,+1958+-+Centro,+S%C3%A3o+Gabriel+do+Oeste+-+MS,+79490-007',
} as const;

export function buildWhatsAppUrl(message: string): string {
  const encoded = encodeURIComponent(message);
  return `https://wa.me/${BUSINESS_INFO.phoneSanitized}?text=${encoded}`;
}

export interface WashService {
  id: string;
  index: string;
  title: string;
  category: string;
  description: string;
  image?: string;
  imageAlt?: string;
  whatsappMessage: string;
}

export const WASH_SERVICES: WashService[] = [
  {
    id: 'lavagem-cesto',
    index: '01.',
    title: 'Lavagem Automática em Cesto',
    category: 'Ciclo completo',
    description:
      'Máquinas profissionais de alta rotação com sabão e amaciante dosados na medida exata.',
    image: '/src/assets/images/service_lavagem_cesto_1794916925654.jpg',
    imageAlt:
      'Tambor de lavadora profissional em aço inox lavando roupas brancas com espuma controlada na Brilho Express',
    whatsappMessage:
      'Olá, equipe Brilho Express! Gostaria de informações sobre a Lavagem Simples (R$ 17,90).',
  },
  {
    id: 'secagem-express',
    index: '02.',
    title: 'Secagem Rápida em Tambor',
    category: 'Pronto para dobrar',
    description:
      'Secadoras industriais com controle térmico para entregar roupas macias e sem umidade.',
    image: '/src/assets/images/service_secagem_rapida_1794916927736.jpg',
    imageAlt:
      'Cliente retirando toalhas brancas dobradas junto à secadora automática na lavanderia Brilho Express',
    whatsappMessage:
      'Olá, equipe Brilho Express! Quero saber sobre os ciclos de Secagem Rápida.',
  },
  {
    id: 'edredons-cobertores',
    index: '03.',
    title: 'Edredons e Cobertores',
    category: 'Lavagem Pesada',
    description:
      'Tambores amplos que lavam e enxáguam peças volumosas sem amassar a fibra.',
    image: '/src/assets/images/service_edredons_pesados_1794916928027.jpg',
    imageAlt:
      'Edredom acolchoado dentro de tambor comercial de grande capacidade na lavanderia automática',
    whatsappMessage:
      'Olá, equipe Brilho Express! Gostaria de informações sobre a Lavagem Pesada (R$ 33,90) para edredons.',
  },
  {
    id: 'dosagem-automatica',
    index: '04.',
    title: 'Insumos Inclusos no Ciclo',
    category: 'Zero preocupação',
    description:
      'Sabão líquido profissional e amaciante hipoalergênico injetados automaticamente.',
    whatsappMessage:
      'Olá, equipe Brilho Express! Quero saber como funciona a dosagem automática de produtos.',
  },
  {
    id: 'higienizacao-toalhas',
    index: '05.',
    title: 'Cama, Mesa e Banho',
    category: 'Higienização térmica',
    description:
      'Água filtrada e enxágue reforçado para renovar lençóis, fronhas e jogos de banho.',
    whatsappMessage:
      'Olá, equipe Brilho Express! Tenho interesse na lavagem de roupas de cama e banho.',
  },
  {
    id: 'roupas-delicadas',
    index: '06.',
    title: 'Ciclo Delicado e Brancas',
    category: 'Cuidado com tecidos',
    description:
      'Programas específicos com menor agitação mecânica para preservar cor e caimento.',
    whatsappMessage:
      'Olá, equipe Brilho Express! Gostaria de consultar o ciclo para peças delicadas.',
  },
];

export interface WashPlan {
  id: string;
  name: string;
  subtitle: string;
  priceFormatted: string;
  unitLabel: string;
  featured?: boolean;
  features: string[];
  whatsappMessage: string;
}

export const WASH_PLANS: WashPlan[] = [
  {
    id: 'lavagem-simples',
    name: 'Lavagem Simples',
    subtitle: 'Ideal para a rotina da semana e roupas do dia a dia',
    priceFormatted: '17,90',
    unitLabel: 'por lavagem',
    features: [
      'Roupas casuais, camisetas, jeans e peças leves',
      'Sabão líquido e amaciante dosados automaticamente',
      'Água filtrada com enxágue limpo e centrifugação forte',
      'Ciclo rápido para levar tudo pronto em minutos',
    ],
    whatsappMessage:
      'Olá, equipe Brilho Express! Gostaria de usar o plano de Lavagem Simples (R$ 17,90).',
  },
  {
    id: 'lavagem-pesada',
    name: 'Lavagem Pesada',
    subtitle: 'Para edredons, cobertores e cargas maiores',
    priceFormatted: '33,90',
    unitLabel: 'por lavagem',
    featured: true,
    features: [
      'Edredons, cobertores, mantas e jogos de cama',
      'Ação reforçada para remoção profunda de sujeira',
      'Insumos profissionais já incluídos no ciclo',
      'Enxágue extra que preserva maciez e volume',
    ],
    whatsappMessage:
      'Olá, equipe Brilho Express! Gostaria de usar o plano de Lavagem Pesada (R$ 33,90).',
  },
];

export interface CustomerReview {
  id: string;
  author: string;
  context: string;
  rating: number;
  quote: string;
}

export const CUSTOMER_REVIEWS: CustomerReview[] = [
  {
    id: 'review-1',
    author: 'Fernanda Almeida',
    context: 'Lavagem Simples · Moradora do Centro',
    rating: 5,
    quote:
      'Deixei de perder o sábado inteiro lavando roupa em casa. Em menos de uma hora saio com o cesto limpo, cheiroso e sem precisar levar sabão.',
  },
  {
    id: 'review-2',
    author: 'Rafael Nogueira',
    context: 'Lavagem Pesada · Edredom Queen',
    rating: 5,
    quote:
      'Meu edredom não cabia na máquina de casa. Na lavagem pesada de R$ 33,90 ficou impecável, bem enxaguado e com um toque macio.',
  },
  {
    id: 'review-3',
    author: 'Juliana Martins',
    context: 'Uso semanal · São Gabriel do Oeste',
    rating: 5,
    quote:
      'Ambiente super limpo, organizado e bem localizado na R. Paraná. O atendimento pelo WhatsApp responde rápido sempre que preciso.',
  },
];

export const HERO_IMAGE = {
  src: '/src/assets/images/hero_lavanderia_automatica_1794916926068.jpg',
  alt: 'Interior moderno da lavanderia automática Brilho Express com lavadoras e secadoras em aço inox iluminadas em azul oceano',
};

export const STUDIO_IMAGE = {
  src: '/src/assets/images/studio_lavanderia_wide_1794916928189.jpg',
  alt: 'Ambiente interno da Brilho Express com máquinas alinhadas e bancada limpa para dobrar roupas',
};
